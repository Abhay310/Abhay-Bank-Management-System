# PUBank
A simple banking system which uses SQLite to maintain a database of all the accounts
